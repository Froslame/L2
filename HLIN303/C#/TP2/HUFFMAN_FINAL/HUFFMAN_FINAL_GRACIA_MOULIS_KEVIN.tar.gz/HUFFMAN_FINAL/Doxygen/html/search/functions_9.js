var searchData=
[
  ['verif',['verif',['../_huffman_8c.html#a740df2e1d5277c49df31ef01aa331661',1,'Huffman.c']]]
];

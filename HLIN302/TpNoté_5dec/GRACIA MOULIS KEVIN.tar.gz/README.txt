Nom : GRACIA MOULIS Kevin

Le tp n'est pas terminer.
Le code va jusqu'à la question 1.2.4 (sans le duplicate et l'operateur =).
